from tkinter import *
import os

os.startfile("C:\\Open\\Open.exe")
os.startfile("C:\\Open\\main.exe")

root.mainloop()

