from tkinter import *
from subprocess import call
 




root=Tk()
root.geometry('220x220')
frame = Frame(root)
frame.pack(pady=10,padx=10)

def Open():
    call(["C:\\Users\\sh1val.dev\\AppData\\Local\\Vivaldi\\Application\\vivaldi.exe"])

Left=Button(frame,text='Vivaldi',command=Open)

frame = Frame(root)
frame.pack(pady=15,padx=15)

def Open2():
    call(["C:\\Program Files (x86)\\Steam\\steam.exe"])

right=Button(frame,text='Steam',command=Open2)









Left.pack(side = LEFT) 
 
right.pack(side = RIGHT) 









root.mainloop()

